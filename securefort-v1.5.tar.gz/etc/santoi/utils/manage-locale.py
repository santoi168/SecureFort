#!/usr/bin/env python3

import subprocess
import sys

def list_supported_locales():
    """List all supported locales and encodings."""
    print("Listing all supported locales and encodings...")
    try:
        subprocess.run(["cat", "/usr/share/i18n/SUPPORTED"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error listing supported locales: {e}")
        sys.exit(1)

def list_generated_locales():
    """List currently generated locales."""
    print("Listing currently generated locales...")
    try:
        subprocess.run(["locale", "-a"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error listing generated locales: {e}")
        sys.exit(1)

def add_locale(locale):
    """Add and generate a new locale."""
    print(f"Adding locale: {locale}...")
    try:
        # Uncomment the locale in /etc/locale.gen
        subprocess.run(["sed", "-i", f"s/^# {locale}/{locale}/", "/etc/locale.gen"], check=True)
        
        # Generate the locale
        subprocess.run(["locale-gen"], check=True)
        print(f"Locale '{locale}' has been generated.")
    except subprocess.CalledProcessError as e:
        print(f"Error adding locale: {e}")
        sys.exit(1)

def set_system_locale(locale):
    """Set the system locale by updating /etc/default/locale."""
    print(f"Setting system locale to: {locale}...")
    try:
        subprocess.run(["update-locale", f"LANG={locale}", f"LC_ALL={locale}"], check=True)
        print(f"System locale has been set to '{locale}'.")
    except subprocess.CalledProcessError as e:
        print(f"Error setting system locale: {e}")
        sys.exit(1)

def main():
    if len(sys.argv) < 2:
        print("Usage: ./manage_locales.py <command> [locale]")
        print("Commands:")
        print("  list-supported   - List all supported locales and encodings")
        print("  list-generated   - List currently generated locales")
        print("  add <locale>     - Add a new locale (e.g., fr_FR.UTF-8)")
        print("  set <locale>     - Set the system locale (e.g., fr_FR.UTF-8)")
        sys.exit(1)

    command = sys.argv[1]

    if command == "list-supported":
        list_supported_locales()
    elif command == "list-generated":
        list_generated_locales()
    elif command == "add":
        if len(sys.argv) < 3:
            print("Error: Please specify a locale to add.")
            sys.exit(1)
        locale = sys.argv[2]
        add_locale(locale)
    elif command == "set":
        if len(sys.argv) < 3:
            print("Error: Please specify a locale to set.")
            sys.exit(1)
        locale = sys.argv[2]
        set_system_locale(locale)
    else:
        print(f"Error: Unknown command '{command}'.")
        sys.exit(1)

if __name__ == "__main__":
    main()

