#!/usr/bin/python3

import re
from datetime import datetime
import sys

def parse_log():
    # Define patterns for "disassociated" and "associated"
    patterns = {
        "disconnected": re.compile(r"wlan0: STA ([0-9a-f:]{17}) IEEE 802.11: disassociated"),
        "connected": re.compile(r"wlan0: STA ([0-9a-f:]{17}) IEEE 802.11: associated")
    }

    devices = {}
    
    # Get the current year
    current_year = datetime.now().year

    for line in sys.stdin:
        # Check for disassociation
        match_disconnected = patterns['disconnected'].search(line)
        if match_disconnected:
            mac = match_disconnected.group(1)
            # Add the current year to the timestamp for proper parsing
            timestamp_str = f"{current_year} {line.split()[0]} {line.split()[1]} {line.split()[2]}"
            timestamp = datetime.strptime(timestamp_str, '%Y %b %d %H:%M:%S')
            devices[mac] = {'status': 'disconnected', 'last_seen': timestamp}
            print(f"Device {mac} disconnected at {timestamp}")

        # Check for association
        match_connected = patterns['connected'].search(line)
        if match_connected:
            mac = match_connected.group(1)
            # Add the current year to the timestamp for proper parsing
            timestamp_str = f"{current_year} {line.split()[0]} {line.split()[1]} {line.split()[2]}"
            timestamp = datetime.strptime(timestamp_str, '%Y %b %d %H:%M:%S')
            devices[mac] = {'status': 'connected', 'last_seen': timestamp}
            print(f"Device {mac} connected at {timestamp}")
    
    # Print the current status of all devices
    print("\nCurrent Device Status:")
    for mac, info in devices.items():
        print(f"Device {mac} is {info['status']} at {info['last_seen']}")

if __name__ == "__main__":
    parse_log()

