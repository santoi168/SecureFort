#!/bin/bash
# Redesigned dashboard layout

INTERVAL=5

while true; do
    clear
    NOW=$(date '+%Y-%m-%d %H:%M:%S')

    echo "==================== SYSTEM STATUS @ $NOW ===================="
    echo

    #
    # CPU + Memory section
    #
    echo " [SYSTEM]"
    printf "   CPU TEMP : %s\n" "$(vcgencmd measure_temp)"
    echo "   MEMORY:"
    free -h | sed 's/^/      /'
    echo

    #
    # Interface Summary Table
    #
    echo " [INTERFACES]"
    printf "%-10s %-8s %-18s %-18s\n" "IFACE" "STATE" "IP ADDRESS" "MAC"
    printf "%-10s %-8s %-18s %-18s\n" "-----" "------" "------------------" "------------------"

    for IFACE in eth0 wlan0 wlan1; do
        if [[ -d /sys/class/net/$IFACE ]]; then
            STATE=$(cat /sys/class/net/$IFACE/operstate 2>/dev/null)
            IP=$(ip -4 addr show $IFACE | awk '/inet /{print $2}' | cut -d/ -f1)
            MAC=$(cat /sys/class/net/$IFACE/address 2>/dev/null)

            [[ -z "$IP" ]] && IP="—"
            [[ -z "$MAC" ]] && MAC="—"

            printf "%-10s %-8s %-18s %-18s\n" "$IFACE" "$STATE" "$IP" "$MAC"
        fi
    done
    echo

    #
    # Connected stations (hostapd)
    #
    echo " [CONNECTED STATIONS - wlan0]"
    STAS=$(sudo hostapd_cli -i wlan0 list_sta | wc -l)
    if (( STAS == 0 )); then
        echo "   No clients connected."
    else
        sudo hostapd_cli -i wlan0 list_sta | sed 's/^/   /'
    fi
    echo

    #
    # WLAN0 radio information
    #
    echo " [WLAN0 RADIO INFO]"
    iw dev wlan0 info | sed 's/^/   /'
    echo
    
    #
    # Detailed per-interface info
    #
    for IFACE in eth0 wlan0 wlan1; do
        STATE=$(cat /sys/class/net/$IFACE/operstate 2>/dev/null)
        if [[ "$STATE" == "up" ]]; then
            echo " [DETAIL: $IFACE]"
            ifconfig $IFACE | sed 's/^/   /'
            echo
        fi
    done

    sleep "$INTERVAL"
done

