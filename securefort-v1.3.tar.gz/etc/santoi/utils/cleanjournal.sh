#!/bin/sh
journalctl --flush
journalctl --rotate
journalctl --vacuum-size=25
journalctl --vacuum-files=3
journalctl --vacuum-time=1w
journalctl --disk-usage
exit 0

