"""
   Command-line utily to reset web account (admin) password to default: santoi!@#
"""
import secrets
from werkzeug.security import generate_password_hash, check_password_hash

hash_passwd = generate_password_hash("santoi!@#")

with open("/etc/santoi/admin/passwd","w", encoding="utf-8") as f:
    f.write(hash_passwd)
