#!/bin/bash
set -e

echo "=== Step 1: Update journald.conf ==="
sudo cp /etc/systemd/journald.conf /etc/systemd/journald.conf.bak.$(date +%s)
sudo sed -i 's/^#*Storage=.*/Storage=volatile/' /etc/systemd/journald.conf
sudo sed -i 's/^#*RuntimeMaxUse=.*/RuntimeMaxUse=30M/' /etc/systemd/journald.conf
if ! grep -q "^Storage=volatile" /etc/systemd/journald.conf; then
    echo "Storage=volatile" | sudo tee -a /etc/systemd/journald.conf
fi
if ! grep -q "^RuntimeMaxUse=30M" /etc/systemd/journald.conf; then
    echo "RuntimeMaxUse=30M" | sudo tee -a /etc/systemd/journald.conf
fi

echo "=== Step 2: Restart systemd-journald ==="
sudo systemctl restart systemd-journald

echo "=== Step 3: Update /etc/fstab with tmpfs for /var/log ==="
sudo cp /etc/fstab /etc/fstab.bak.$(date +%s)
if ! grep -q "/var/log" /etc/fstab; then
    echo "tmpfs   /var/log    tmpfs   defaults,noatime,nosuid,mode=0755,size=50m   0   0" | \
    sudo tee -a /etc/fstab
else
    echo "Entry for /var/log already exists in /etc/fstab. Skipping."
fi

echo "=== Step 4: Update santoi-nginx.conf systemd service ==="
NGINX_SERVICE="/etc/systemd/system/santoi-nginx.service"
if [ -f "$NGINX_SERVICE" ]; then
    sudo cp "$NGINX_SERVICE" "$NGINX_SERVICE.bak.$(date +%s)"
    if ! grep -q "ExecStartPre=/bin/mkdir -p /var/log/nginx" "$NGINX_SERVICE"; then
        sudo sed -i "/^\[Service\]/a ExecStartPre=/bin/mkdir -p /var/log/nginx" "$NGINX_SERVICE"
    fi
    if ! grep -q "ExecStartPre=/bin/chown www-data:www-data /var/log/nginx" "$NGINX_SERVICE"; then
        sudo sed -i "/ExecStartPre=\/bin\/mkdir -p \/var\/log\/nginx/a ExecStartPre=/bin/chown www-data:www-data /var/log/nginx" "$NGINX_SERVICE"
    fi
else
    echo "Warning: $NGINX_SERVICE not found. Skipping."
fi

