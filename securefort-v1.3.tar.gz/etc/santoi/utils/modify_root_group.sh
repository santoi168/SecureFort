#!/bin/bash

echo "Enter username:"
read username
echo "Command option: add/remove $username to root group: "
read command
if [ "$command" == "add" ]; then
    sudo usermod -aG root "$username"
elif [ "$command" == "remove" ]; then
    sudo deluser "$username" root
else
    echo "Invalid option. Please enter 'add' or 'remove'."
    exit 1
fi
echo "Completed."

exit 0