#!/bin/bash

# Define the blocklist source (change this to your preferred list)
BLOCKLIST_URL="https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"

# Define where to save the blocklist
BLOCKLIST_FILE="/etc/adblock.list"

# Download the latest blocklist
curl -sSL $BLOCKLIST_URL | grep "^0.0.0.0" > $BLOCKLIST_FILE

# Restart dnsmasq to apply changes
sudo systemctl restart dnsmasq

# Log the update time
echo "Blocklist updated on $(date)" | sudo tee -a /var/log/dnsmasq-blocklist.log
