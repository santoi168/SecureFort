import secrets

secret_key = secrets.token_hex(32)
print(secret_key)

# Please modify /etc/environment and update the environment variable, SECRET_KEY
