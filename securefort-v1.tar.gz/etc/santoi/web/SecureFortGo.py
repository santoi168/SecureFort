import subprocess
from flask import Flask, Response, request, redirect
import requests
import threading
import logging

class SecureFortGunicornApp:
    def __init__(self, executable_path, host="127.0.0.1", port=5000, timeout=90):
        self.executable_path = executable_path
        self.host = host
        self.port = port
        self.timeout = timeout  # Timeout in seconds
        self.proc = None  # To hold the subprocess

    def start_executable(self):
        # Launch the PyInstaller executable
        self.proc = subprocess.Popen([self.executable_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    def stop_executable(self):
        if self.proc:
            self.proc.terminate()

    def create_proxy_app(self):
        # Create a Flask app to act as a reverse proxy
        proxy_app = Flask(__name__)

        # Enable logging
        proxy_app.logger.setLevel(logging.DEBUG)

        @proxy_app.route('/', defaults={'path': ''})
        @proxy_app.route('/<path:path>', methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
        def proxy(path):
            # Log incoming request details for debugging
            proxy_app.logger.debug(f"Received {request.method} request for path: {path}")
            proxy_app.logger.debug(f"Request Headers: {request.headers}")
            proxy_app.logger.debug(f"Request Data: {request.get_data()}")

            # Forward the request to the executable's internal server
            # target_url = f"http://{self.host}:{self.port}/{path}"
            target_url = request.args.get('url')
            if target_url == "http://www.neverssl.com":
                second_app_url = "http://127.0.0.1:5000/proxy"
                proxy_app.logger.debug(f"Using external target URL: {target_url}")
                try:
                    session = requests.Session()
                    response = session.get(second_app_url, params={'url': target_url}, allow_redirects=False, timeout=self.timeout)
                    # Check if the response is a redirect
                    proxy_app.logger.debug(f"response.status_code received from internal proxy: {response.status_code}")
                    proxy_app.logger.debug(f"response headers are {response.headers}")
                    if 300 <= response.status_code < 400:
                        # Modify the redirect URL if necessary
                        location = response.headers.get('Location', '')
                        if location:
                            proxy_app.logger.debug(f"Forwarding redirect to client: {location}")
                            proxy_app.logger.debug(f"response.status_code received: {response.status_code}")                              
                            try:
                                # Stream the response manually to handle chunking issues
                                with session.get(location, timeout=self.timeout):
                                    return redirect(location, code=response.status_code)
                            except requests.exceptions.RequestException as e:
                                proxy_app.logger.error(f"Error forwarding request to redirected URL: {e}")
                                return f"Error forwarding request to redirected URL: {e}", 500
                    # Return the response to the client
                    return Response(response.content, response.status_code, response.headers.items())
                except requests.exceptions.RequestException as e:
                    proxy_app.logger.error(f"Error forwarding request to second app: {e}")
                    return f"Error forwarding request to second app: {e}", 500                    
            else:
                # Construct the target URL based on internal server
                target_url = f"http://{self.host}:{self.port}/{path}"
                proxy_app.logger.debug(f"Using internal target URL: {target_url}")
                try:
                    # Forward the request to the target URL with timeout
                    response = requests.request(
                        method=request.method,  # Forward the method (GET, POST, etc.)
                        url=target_url,  # The URL of the internal executable server
                        headers={key: value for key, value in request.headers},  # Forward headers
                        data=request.get_data(),  # Forward the body (e.g., form data)
                        cookies=request.cookies,  # Forward cookies
                        allow_redirects=False,  # Do not follow redirects automatically
                        timeout=self.timeout  # Set the timeout for the request
                    )

                    # Check if the response is a redirect
                    proxy_app.logger.debug(f"response.status_code received is {response.status_code}.")
                    if 300 <= response.status_code < 400:
                        # Modify the redirect URL if necessary
                        location = response.headers.get('Location', '')
                        if location:
                            # Here you can modify the Location URL to use the proxy path
                            # For example, change internal URL to external URL
                            new_location = f"http://{request.host}{location}"  # Modify based on the actual proxy host
                            response.headers['Location'] = new_location
                            proxy_app.logger.debug(f"Redirecting to: {new_location}")
                    # Return the response to the client
                    return Response(response.content, response.status_code, response.headers.items())

                except requests.exceptions.RequestException as e:
                    # Log the error if the request to the executable fails
                    proxy_app.logger.error(f"Error proxying request: {e}")
                    return f"Error proxying request: {e}", 500

        return proxy_app

# Instantiate the SecureFortGunicornApp with the path to your executable and a custom timeout
executable_path = "/etc/santoi/bin/SecureFort"
timeout = 90  # Set the timeout to 15 seconds (default is 10)
secure_fort = SecureFortGunicornApp(executable_path, timeout=timeout)

# Start the PyInstaller executable in a separate thread
threading.Thread(target=secure_fort.start_executable).start()

# Create the proxy app and expose it as 'app'
app = secure_fort.create_proxy_app()

if __name__ == "__main__":
    # Run the Flask app to serve proxy requests on all IP addresses
    app.run(host="127.0.0.1", port=8000)
