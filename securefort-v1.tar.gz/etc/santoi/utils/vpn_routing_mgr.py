#!/usr/bin/python3
"""
    Docstring placeholder
"""
import subprocess
import time
import sys


# if sys.platform == "linux":
#    sys.path.append('/etc/santoi/components/')
#     from network import ManagedUtils, NetUtils, AccessPointUtils
#     from system import SystemUtils
# elif sys.platform == "darwin":
#     from components.network import ManagedUtils, NetUtils, AccessPointUtils
#     from components.system import SystemUtils

def flush_iptables_rules(logger):
    """
    docstring placeholder
    """
    try:
        # List of commands to flush all iptables rules and chains
        commands = [
            ["sudo", "iptables", "-F"],  # Flush all the rules in the filter table
            ["sudo", "iptables", "-X"],  # Delete all non-builtin chains in the filter table
            ["sudo", "iptables", "-t", "nat", "-F"],  # Flush all the rules in the nat table
            ["sudo", "iptables", "-t", "nat", "-X"],  # Delete all non-builtin chains in the nat table
            ["sudo", "iptables", "-t", "mangle", "-F"],  # Flush all the rules in the mangle table
            ["sudo", "iptables", "-t", "mangle", "-X"],  # Delete all non-builtin chains in the mangle table
            ["sudo", "iptables", "-t", "raw", "-F"],  # Flush all the rules in the raw table
            ["sudo", "iptables", "-t", "raw", "-X"]   # Delete all non-builtin chains in the raw table
            ]

        # Execute each command
        for command in commands:
            subprocess.run(command, check=True)
            if logger:
                logger.debug("All iptables rules and chains have been flushed successfully.")
            else:
                print("All iptables rules and chains have been flushed successfully.")

    except subprocess.CalledProcessError as e:
        if logger:
            logger.debug(f"An error occurred on flushing iptables rules: {e}")
        else:
            print(f"An error occurred on flushing iptables rules: {e}")

def check_interface_exists(interface):
    """
    docstring placeholder
    """
    # Run 'ip link' to list network interfaces
    try:
        print(f"check_interface_exists - {interface}.")
        result = subprocess.run(["ip", "link"], capture_output=True, text=True, check=True)
        if any(interface in line for line in result.stdout.splitlines()):
            return True
    except subprocess.CalledProcessError as e:
        print(f"check_interface_exists - {interface} failed. ErrMsg: {e}")
    # Check if the interface name is in the output
    return False
    
def check_internet(interface):
    """
        Docstring placeholder
    """
    try:
        # Ping Google's DNS server (8.8.8.8) using the specified interface
        # if NetUtils.check_interface_exists(interface):
        if check_interface_exists(interface): 
            print(f"check_interface(), {interface}") 
            subprocess.check_output(["sudo", 'ping', '-I', interface, '-c', '1', '8.8.8.8'], stderr=subprocess.STDOUT)
            return True
        return False
    except subprocess.CalledProcessError as e:
        print(f"vpn_routing_mgr, check_interface() - Error detected. {e}")
        return False

def restore_iptables(rules_file):
    """
        Docstring placeholder
    """
    try:
        # Run the iptables-restore command with the rules file
        # NetUtils.flush_iptables_rules(None)
        flush_iptables_rules(None)
        subprocess.check_call(['sudo', 'iptables-restore', rules_file])
        print(f"iptables rule, on {rules_file}, restored successfully.\n")
    except subprocess.CalledProcessError as e:
        print(f"vpn_routing_mgr, restore_iptables() - Failed to restore iptables rules: {e}\n")

def main():
    """
        Docstring placeholder
    """
    # EXT_INT=os.getenv('EXTERNAL', 'wlan0')
    interfaces = ['wlan0_ext', 'wlan1', 'eth0']
    for interface in interfaces:
        if check_internet(interface):
            print(f"{interface} has internet access.\n")
            return interface
    print("vpn_routing_mgr, main() - None of [{interfaces}] has internet access.\n")
    return None

if __name__ == "__main__":
    rule_set = None
    active_interface = main()
    print("active_interface: ", active_interface)
    operation_command = sys.argv[1].strip()

    if operation_command == "up":
        vpn_type = sys.argv[2].strip()
        if vpn_type == "openvpn":
            nameserver = sys.argv[3].strip()
            if active_interface == "eth0":
                print("vpn-eth0")
                rule_set = "/etc/santoi/rules/iptables.up.vpn-eth0"
            elif active_interface == "wlan1":
                print("vpn-wlan1")
                rule_set = "/etc/santoi/rules/iptables.up.vpn-wlan1"
            elif active_interface == "wlan0":
                print("vpn-wlan1")
                rule_set = "/etc/santoi/rules/iptables.up.vpn-wlan0"

        elif vpn_type == "wg":
            profile_name = sys.argv[3].strip() 
            if active_interface == "eth0":
                rule_set = f"/etc/santoi/rules/iptables.up.{profile_name}-eth0"
            elif active_interface == "wlan1":
                rule_set = f"/etc/santoi/rules/iptables.up.{profile_name}-wlan1"
            elif active_interface == "wlan0":
                rule_set = f"/etc/santoi/rules/iptables.up.{profile_name}-wlan0"

    elif operation_command == "down":
        if active_interface == "eth0":
            rule_set = "/etc/santoi/rules/iptables.up.eth0"
        elif active_interface == "wlan1":
            rule_set = "/etc/santoi/rules/iptables.up.wlan1"
        elif active_interface == "wlan0":
            rule_set = "/etc/santoi/rules/iptables.up.wlan0"

    if rule_set:
        # Reload the new routing rules.
        restore_iptables(rule_set)
        # After reloading the routing rules, restart DNS service
        time.sleep(3)
        subprocess.run(["sudo", "systemctl", "restart", "dnsmasq"], check=True)

